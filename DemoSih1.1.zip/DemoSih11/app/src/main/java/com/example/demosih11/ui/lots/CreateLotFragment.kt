package com.example.demosih11.ui.lots

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.demosih11.R
import com.example.demosih11.databinding.FragmentCreateLotBinding
import com.example.demosih11.db.AppDatabase
import com.example.demosih11.db.Lot
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class CreateLotFragment : Fragment() {
    private var _binding: FragmentCreateLotBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCreateLotBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.editWeight.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { calculateEstimate() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.chipGroupCategory.setOnCheckedChangeListener { _, _ -> calculateEstimate() }

        binding.btnSave.setOnClickListener {
            saveLot()
        }
    }

    private fun calculateEstimate() {
        val weight = binding.editWeight.text.toString().toDoubleOrNull() ?: 0.0
        val selectedChipId = binding.chipGroupCategory.checkedChipId
        if (selectedChipId == View.NO_ID) {
            binding.txtEstimate.text = "₹ 0.00"
            return
        }
        
        val selectedChip = binding.root.findViewById<Chip>(selectedChipId)
        val rate = when (selectedChip.text.toString()) {
            getString(R.string.cat_pcb) -> 350.0
            getString(R.string.cat_battery) -> 85.0
            getString(R.string.cat_cable) -> 450.0
            else -> 0.0
        }
        
        val estimate = weight * rate
        binding.txtEstimate.text = "₹ %.2f".format(estimate)
    }

    private fun saveLot() {
        val weight = binding.editWeight.text.toString().toDoubleOrNull()
        val selectedChipId = binding.chipGroupCategory.checkedChipId
        
        if (weight == null || selectedChipId == View.NO_ID) {
            Toast.makeText(requireContext(), "Please fill all details", Toast.LENGTH_SHORT).show()
            return
        }

        val category = binding.root.findViewById<Chip>(selectedChipId).text.toString()
        val rate = when (category) {
            getString(R.string.cat_pcb) -> 350.0
            getString(R.string.cat_battery) -> 85.0
            getString(R.string.cat_cable) -> 450.0
            else -> 0.0
        }

        val lot = Lot(
            category = category,
            weight = weight,
            estimatedValue = weight * rate
        )

        lifecycleScope.launch {
            AppDatabase.getDatabase(requireContext()).lotDao().insertLot(lot)
            Toast.makeText(requireContext(), "Lot Saved Offline", Toast.LENGTH_SHORT).show()
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}