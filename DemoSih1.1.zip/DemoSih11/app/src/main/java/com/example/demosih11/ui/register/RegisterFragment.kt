package com.example.demosih11.ui.register

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.demosih11.R
import com.example.demosih11.databinding.FragmentRegisterBinding
import com.example.demosih11.model.RegistrationCache
import com.example.demosih11.util.LocationHelper
import com.google.android.material.bottomnavigation.BottomNavigationView

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    private var isPhotoCaptured = false

    private val requestLocationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            performRegistration()
        } else {
            Toast.makeText(requireContext(), "Location access is mandatory for security verification", Toast.LENGTH_LONG).show()
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isPermissionGranted()) {
            takePictureLauncher.launch(null)
        } else {
            Toast.makeText(requireContext(), "Camera permission is required to take photos", Toast.LENGTH_LONG).show()
        }
    }

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            isPhotoCaptured = true
            binding.textAadharPhotoStatus.text = "✓ aadhar_scan.jpg uploaded"
            binding.textAadharPhotoStatus.setTextColor(resources.getColor(android.R.color.holo_green_dark, null))
            Toast.makeText(requireContext(), "Aadhar document captured successfully", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Camera cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isPermissionGranted() = ContextCompat.checkSelfPermission(
        requireContext(), Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        activity?.findViewById<BottomNavigationView>(R.id.bottom_nav)?.visibility = View.GONE

        binding.btnCaptureAadhar.setOnClickListener {
            if (isPermissionGranted()) {
                takePictureLauncher.launch(null)
            } else {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnSubmitRegister.setOnClickListener {
            requestLocationPermissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }

        binding.textBackToLogin.setOnClickListener {
            findNavController().navigate(R.id.loginFragment)
        }
    }

    private fun performRegistration() {
        LocationHelper.checkLocationInIndia(requireContext()) { isInIndia ->
            if (isInIndia) {
                val first = binding.editFirstName.text.toString().trim()
                val last = binding.editLastName.text.toString().trim()
                val phone = binding.editPhone.text.toString().trim()
                val email = binding.editEmail.text.toString().trim()
                val aadhar = binding.editAadhar.text.toString().trim()
                val gst = binding.editGst.text.toString().trim()
                val pass = binding.editRegPassword.text.toString()
                val confirm = binding.editRegConfirmPassword.text.toString()

                if (first.isEmpty() || last.isEmpty() || phone.isEmpty() || aadhar.isEmpty() || gst.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
                    Toast.makeText(requireContext(), "Please complete all fields (Email is optional)", Toast.LENGTH_SHORT).show()
                    return@checkLocationInIndia
                }

                if (pass != confirm) {
                    Toast.makeText(requireContext(), "Security Error: Passwords do not match", Toast.LENGTH_SHORT).show()
                    return@checkLocationInIndia
                }

                if (!isPhotoCaptured) {
                    Toast.makeText(requireContext(), "Please take an Aadhar Card photo for KYC validation", Toast.LENGTH_SHORT).show()
                    return@checkLocationInIndia
                }

                val checkedId = binding.toggleGroupRegRole.checkedButtonId
                val roleName = if (checkedId == R.id.btnRegRoleRecycler) "Recycler" else "Kabadi Wala"

                // Save user data
                RegistrationCache.pendingApplications.add(
                    RegistrationCache.UserRegistration(
                        role = roleName,
                        firstName = first,
                        lastName = last,
                        phone = phone,
                        email = if (email.isEmpty()) "Not provided" else email,
                        aadharNo = aadhar,
                        gstNo = gst
                    )
                )

                Toast.makeText(
                    requireContext(),
                    "Registration submitted successfully for $roleName! Pending admin approval.",
                    Toast.LENGTH_LONG
                ).show()

                findNavController().navigate(R.id.loginFragment)
            } else {
                Toast.makeText(requireContext(), "Access Denied: Registration only available within India territory", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}