package com.example.demosih11.model

object RegistrationCache {
    
    data class UserRegistration(
        val role: String,
        val firstName: String,
        val lastName: String,
        val phone: String,
        val email: String,
        val aadharNo: String,
        val gstNo: String,
        var isVerified: Boolean = false
    )

    val pendingApplications = mutableListOf<UserRegistration>(
        // Seed default application entries for demonstration purposes
        UserRegistration("Kabadi Wala", "Rajesh", "Kumar", "9876543210", "rajesh@kabadi.com", "5241-8963-7412", "07AAAAA1111A1Z1"),
        UserRegistration("Recycler", "Amit", "Sharma", "9911223344", "contact@greentech.in", "4125-9632-8521", "09BBBBB2222B1Z2")
    )
}